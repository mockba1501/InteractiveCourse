
const Favorites = () => {
  return (
    <div className="favorites-section">
      Favorites Section
    </div>
  )
}

export default Favorites
