import { useState } from "react";

const Search = () => {
  
  return (
    <div className="row">
      Search Component
    </div>
  );
}

export default Search
