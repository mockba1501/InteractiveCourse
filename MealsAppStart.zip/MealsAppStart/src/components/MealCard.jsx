import React from 'react'

const MealCard = () => {
  return (
    <div className="meal">
      Meal Card
    </div>
  )
}

export default MealCard
