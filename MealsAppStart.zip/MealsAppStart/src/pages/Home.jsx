import Search from "../components/Search";
import Favorites from "../components/Favorites";
import MealCard from "../components/MealCard";

const Home = () => {

  return (
    <div className="store">
    <Search/>
    
    <Favorites />
    
    <div className="meals" id="meals">
      <MealCard />
    </div>
    
  </div>
  )
}

export default Home
